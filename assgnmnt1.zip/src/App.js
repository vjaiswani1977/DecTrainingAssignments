import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <b>Hello</b>
      <br/>Home page for assignment 1
    </div>
  );
}

export default App;
